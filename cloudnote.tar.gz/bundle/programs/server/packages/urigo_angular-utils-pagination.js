(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['urigo:angular-utils-pagination'] = {};

})();

//# sourceMappingURL=urigo_angular-utils-pagination.js.map
