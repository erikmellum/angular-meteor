(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['angularjs:angular-animate'] = {};

})();

//# sourceMappingURL=angularjs_angular-animate.js.map
